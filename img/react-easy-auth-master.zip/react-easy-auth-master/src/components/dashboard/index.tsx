function Dashboard() {}

export { Dashboard };
