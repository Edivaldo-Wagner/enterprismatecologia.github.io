function Register(props: any) {}

export { Register };
